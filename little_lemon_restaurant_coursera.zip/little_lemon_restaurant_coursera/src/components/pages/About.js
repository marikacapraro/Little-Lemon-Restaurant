import Heading from "../sections/aboutPages/Heading";
export default function About() {
  return (
    <>
      <Heading />
    </>
  );
}
